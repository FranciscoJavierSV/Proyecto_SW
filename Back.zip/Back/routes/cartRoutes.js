const express = require('express');
const router = express.Router();

const { verifyT } = require('../middleware/authMiddleware');
const cart = require('../controllers/cart');

// Obtener carrito del usuario
router.get('/cart', verifyT, cart.getCart);

// Agregar producto al carrito
router.post('/cart', verifyT, cart.addToCart);

// Actualizar cantidad (+1 / -1)
router.patch('/cart/:productId', verifyT, cart.updateQuantity);

// Eliminar producto del carrito
router.delete('/cart/:id', verifyT, cart.deleteItem);

module.exports = router;
