// Contacto y suscripción
const sendContact = async (req, res) => {
  try {
    // Enviar mensaje de contacto
  } catch (error) {
    // Manejo de errores
  }
};

const subscribe = async (req, res) => {
  try {
    // Suscribirse y recibir cupón
  } catch (error) {
    // Manejo de errores
  }
};

module.exports = {
  sendContact,
  subscribe
};